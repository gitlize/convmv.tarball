#!/bin/sh
for d in `ls -d test*` ; do cd $d ; ls -R -g -G --time-style=+ >../out-$d ; cd .. ; done
#
rm -rf test2
cp -a test test2
../convmv -f iso8859-15 -t utf8 --notest -r test2
cd test2
ls -R -g -G --time-style=+ >../out2
cd ..
diff out-test out2 || (echo smartness-test failed. ; exit1)
#
../convmv -f iso8859-15 -t utf8 --notest -r --nosmart test2
cd test2
ls -R -g -G --time-style=+ >../out2
cd ..
pwd
diff out-test-utf8 out2 || (echo double-utf8 test failed. ; exit 1)
#
../convmv -f utf8 -t iso8859-15 --notest -r test2
cd test2
ls -R -g -G --time-style=+ >../out2
cd ..
pwd
diff out-test out2 || (echo undo-double-utf8 test failed. ; exit1)
#
rm -r test2
cp -a test test2
../convmv -f utf8 -t iso8859-15 --notest -r test2
cd test2
ls -R -g -G --time-style=+ >../out2
cd ..
diff out-test-iso8859-15 out2 || (echo iso8859-15-test failed. ; exit 1)
#
rm -r test2
cp -a test test2
../convmv -f utf8 -t utf8 --nfd --notest -r test2
cd test2
ls -R -g -G --time-style=+ >../out2
cd ..
diff out-test-nfd out2 || (echo nfd-test failed. ; exit 1)
#
../convmv -f utf8 -t utf8 --nfc --notest -r test2
cd test2
ls -R -g -G --time-style=+ >../out2
cd ..
diff out-test out2 || (echo nfc-test failed. ; exit 1)
